package gitHT_project;

public class CtraeteTestBranch {

	public static void main(String[] args) {
		System.out.println("created test branch");
		System.out.println("test branch commit2");
	}

}
