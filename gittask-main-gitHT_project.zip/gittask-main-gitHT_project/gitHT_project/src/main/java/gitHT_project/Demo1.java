package gitHT_project;

public class Demo1 {

	public static void main(String[] args) {
		System.out.println("first commit after clone");
		System.out.println("second commit into main");
	}

}
