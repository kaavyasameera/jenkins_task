package gitHT_project;

public class Cherry_pick {

	public static void main(String[] args) {
		System.out.println("commit1 for cherry pick");


		System.out.println("commit2 for cherry pick");


	}

}
