package gitHT_project;

public class Rebase {

	public static void main(String[] args) {
		System.out.println("rebase commit1 in test");
		System.out.println("rebase commit2 in test");
	}

}
